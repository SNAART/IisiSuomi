package com.example.iisisuomi;

public class QuestionLibrary {
    private String mQuestion[] = {
            "Opiskelija",
            "Asua",
            "Puhua",
            "Täällä",

            "Raha",
            "Halpa",
            "Perhe",
            "Muu",

            "Sää",
            "Kitara",
            "Otsikko",
            "Nukkua",

            "Bussikuski",
            "Vaalea",
            "Ujo",
            "Pyörä",

            "Herätyskello",
            "Muroja",
            "Voileipä",
            "Pankki"

    };

    private String mChoices [][] = {
            {"Teacher", "Student", "School"},
            {"To Live", "To Go", "To Speak"},
            {"To Speak", "To Come", "To Learn"},
            {"Now", "Here", "Tomorrow"},

            {"To Buy", "Gold", "Money"},
            {"Cheap", "Much", "Expensive"},
            {"Cousin", "Parents", "Family"},
            {"Exactly", "Same", "Different"},

            {"Sea", "Weather", "Today"},
            {"Violin", "Guitar", "Football"},
            {"Title", "Award", "Medal"},
            {"To Play", "To Eat", "To Sleep"},

            {"Bus Driver", "Bus Station", "Bus Stop"},
            {"Blonde", "Curly", "Dark"},
            {"Laugh", "Cry", "Shy"},
            {"Car", "Bicycle", "Motorbike"},

            {"Clock", "Alarm", "Alarm Clock"},
            {"Cereal", "Bread", "Pancake"},
            {"Hot Dog", "Juice", "Sandwich"},
            {"Museum", "Bank", "Clinic"}
    };

    private String mCorrectAnswers[] = {"Student", "To Live", "To Speak", "Here", "Money", "Cheap", "Family", "Different", "Weather", "Guitar", "Title", "To Sleep", "Bus Driver", "Blonde", "Shy", "Bicycle", "Alarm Clock", "Cereal", "Sandwich", "Bank"};

    public String getQuestion(int a) {
        String question = mQuestion[a];
        return question;
    }
    public int getLength(){
        return mQuestion.length;
    }

    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }

    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }
}

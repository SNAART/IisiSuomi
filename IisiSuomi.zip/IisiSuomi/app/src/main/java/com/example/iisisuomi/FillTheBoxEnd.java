package com.example.iisisuomi;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class FillTheBoxEnd extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fill_the_box_end);
    }

    public void onRepeatClick(View view){
        Intent intent = new Intent(FillTheBoxEnd.this, FillTheBoxIntro.class);
        startActivity(intent);
    }

    public void onExitClick(View view){
        Intent intent = new Intent(FillTheBoxEnd.this, MainActivity.class);
        startActivity(intent);
    }
}
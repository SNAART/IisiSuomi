package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Vocabulary extends AppCompatActivity {
    private App app;
    private Button button_next,button_pre,button_des, button_confirm;
    private CheckBox chapter1, chapter2, chapter3, chapter4, chapter5;
    private TextView word, des, count_text;
    private List<Word> usedWord;
    private int totalWord;
    private int count;
    private List<String> chapterChoice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_vocabulary);
        app = new App(this);
        word = (TextView) findViewById(R.id.word);
        des = (TextView) findViewById(R.id.des);
        count_text = (TextView) findViewById(R.id.text_count);
        button_des = (Button) findViewById(R.id.button_vocab_des);
        button_pre = (Button) findViewById(R.id.button_vocab_pre);
        button_next = (Button) findViewById(R.id.button_vocab_next);
        button_confirm = (Button) findViewById(R.id.button_confirm);
        chapter1 = (CheckBox) findViewById(R.id.checkbox_chaper1);
        chapter2 = (CheckBox) findViewById(R.id.checkbox_chaper2);
        chapter3 = (CheckBox) findViewById(R.id.checkbox_chaper3);
        chapter4 = (CheckBox) findViewById(R.id.checkbox_chaper4);
        chapter5 = (CheckBox) findViewById(R.id.checkbox_chaper5);

        usedWord = new ArrayList<>();
        totalWord = 0;
        count = 0;

        Intent ChapterSelect_Intent = getIntent();
        Bundle ChapterSelect_Bundle = ChapterSelect_Intent.getExtras();

        chapterChoice = new ArrayList<>();
        chapterChoice = ChapterSelect_Bundle.getStringArrayList("Chapters");
        usedWord = new ArrayList<>();
        for(int i = 0; i < chapterChoice.size(); i++) {
            totalWord += app.getChapter(chapterChoice.get(i)).getWordList().size();
        }
    }

    public void ConfirmOnClick(View view) {
        List<String> chapters = new ArrayList<>();
        if (chapter1.isChecked()) {
            chapters.add("1");
        }
        if (chapter2.isChecked()) {
            chapters.add("2");
        }
        if (chapter3.isChecked()) {
            chapters.add("3");
        }
        if (chapter4.isChecked()) {
            chapters.add("4");
        }
        if (chapter5.isChecked()) {
            chapters.add("5");
        }
        totalWord = 0;
        count = 0;
        word.setText("Random");
        count_text.setText("count");
        usedWord = new ArrayList<>();
        for(int i = 0; i < chapters.size(); i++) {
            totalWord += app.getChapter(chapters.get(i)).getWordList().size();
        }
        chapterChoice = chapters;
    }

    public void PreOnClick(View view){
        if (count <= 1) {
            return;
        }
        count--;
        word.setText(usedWord.get(count - 1).getWord());
        count_text.setText(count + " out of " + totalWord);
        des.setText("description");
    }

    public void DesOnClick(View view){
        Word ranWord;
        ranWord = app.getWord(word.getText().toString());
        if (ranWord == null) {
            ranWord = new Word("no name", "no description found", new Chapter("201"));
        }
        des.setText(ranWord.getDescription());
    }


    public void NextOnClick(View view){
        if (count < usedWord.size()) {
            word.setText(usedWord.get(count).getWord());
            count++;
            count_text.setText(count + " out of " + totalWord);
            des.setText("description");
            return;
        }
        while(count <= totalWord) {
            Word ranWord;
            if (count == totalWord) {
                word.setText("end");
                break;
            }
            ranWord = app.getRandomWordBaseOnChapter(chapterChoice);
            if (!(usedWord.contains(ranWord))) {
                word.setText(ranWord.getWord());
                usedWord.add(ranWord);
                count++;
                count_text.setText(count + " out of " + totalWord);
                des.setText("description");
                break;
            }
        }
    }
}

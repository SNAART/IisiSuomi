package com.example.myapplication;

public class Common {
    public static char[] user_submit_answer;
    public static int count = 1;
    public static String[] alphabet_character={
            "a", "b", "c", "d", "e", "f", "g",
            "h", "i", "j", "k", "l", "m", "n",
            "o", "p", "q", "r", "s", "t", "u",
            "v", "w", "x", "y", "z", "å", "ä", "ö"
    };
}
